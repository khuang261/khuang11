import csv
import random
from flask import Flask
app = Flask(__name__) #create instance of class Flask

@app.route("/")       #assign fxn to route


dic = {}

with open('occupations.csv', 'r') as csv_file:
    csv_reader = csv.DictReader(csv_file)
    for row in csv_reader:
        job_name = row['Job Class']
        if job_name == 'Total':
            break
        percentage = float(row['Percentage'])
        dic[job_name] = percentage
def random_occupation():
    return random.choices(list(dic.keys()), list(dic.values()), k=1)[0]

print(random_occupation())

def hello_world():
    print("the __name__ of this module is... ")
    print(__name__)
    return "No hablo queso!"
    return "hey whats up"

if __name__ == "__main__":  # true if this file NOT imported
    app.debug = True        # enable auto-reload upon code change
    app.run()
